// You can add custom JS here. For now, it's just a placeholder.
document.addEventListener('DOMContentLoaded', function() {
    // Example: focus the first input field
    const firstInput = document.querySelector('form input');
    if (firstInput) firstInput.focus();
});
